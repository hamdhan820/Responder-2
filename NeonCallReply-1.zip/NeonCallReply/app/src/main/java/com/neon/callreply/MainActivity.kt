package com.neon.callreply

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

object Prefs {
    val defaults = mapOf(
        "Worship" to "I'm at worship right now. I'll call you back soon.",
        "Meeting" to "I'm in a meeting. I'll call you back as soon as I'm done.",
        "Market" to "I'm at the market right now. I'll call you back shortly."
    )
    fun message(p: SharedPreferences, status: String) =
        p.getString("msg_$status", defaults[status]) ?: ""
}

class MainActivity : AppCompatActivity() {
    private val ids = mapOf(R.id.rWorship to "Worship", R.id.rMeeting to "Meeting", R.id.rMarket to "Market")
    private val pins = mapOf(R.id.pinWorship to "Worship", R.id.pinMeeting to "Meeting", R.id.pinMarket to "Market")
    private lateinit var detected: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val prefs = getSharedPreferences("auto", Context.MODE_PRIVATE)
        val group = findViewById<RadioGroup>(R.id.group)
        val msg = findViewById<EditText>(R.id.message)
        val enabled = findViewById<Switch>(R.id.enabled)
        detected = findViewById(R.id.detected)

        var current = "Worship"  // only used for choosing which message to edit
        group.check(ids.entries.first { it.value == current }.key)
        msg.setText(Prefs.message(prefs, current))
        enabled.isChecked = prefs.getBoolean("enabled", false)

        group.setOnCheckedChangeListener { _, id ->
            current = ids[id]!!
            msg.setText(Prefs.message(prefs, current))
        }
        findViewById<Button>(R.id.save).setOnClickListener {
            prefs.edit().putString("msg_$current", msg.text.toString()).apply()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }
        pins.forEach { (id, status) ->
            findViewById<Button>(id).setOnClickListener {
                val ok = Detector.saveHere(this, status)
                Toast.makeText(
                    this,
                    if (ok) "$status place saved" else "Couldn't get location. Allow location and try again.",
                    Toast.LENGTH_LONG
                ).show()
                refresh()
            }
        }

        val bgs = intArrayOf(R.drawable.bg_cubes, R.drawable.bg_polygons, R.drawable.bg_swirl)
        var bi = prefs.getInt("bg", 0)
        val bg = findViewById<ImageView>(R.id.bg)
        bg.setImageResource(bgs[bi])
        findViewById<Button>(R.id.theme).setOnClickListener {
            bi = (bi + 1) % bgs.size
            prefs.edit().putInt("bg", bi).apply()
            bg.setImageResource(bgs[bi])
        }

        enabled.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("enabled", on).apply()
            if (on) ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
                    Manifest.permission.SEND_SMS, Manifest.permission.READ_CALENDAR,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ), 1
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        // Background location must be requested separately (Android 10+)
        if (code == 1 && Build.VERSION.SDK_INT >= 29) ActivityCompat.requestPermissions(
            this, arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2
        )
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        detected.text = "Detected now: " + (Detector.detect(this) ?: "unknown (no reply will be sent)")
    }
}
