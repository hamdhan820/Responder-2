package com.neon.callreply

import android.annotation.SuppressLint
import android.content.ContentUris
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.provider.CalendarContract

/** Works out the user's current status automatically. */
object Detector {
    val places = listOf("Worship", "Market", "Meeting")
    private const val RADIUS_M = 150f

    fun detect(c: Context): String? {
        try { if (inCalendarEvent(c)) return "Meeting" } catch (_: Exception) {}
        val loc = lastLocation(c) ?: return null
        val p = c.getSharedPreferences("auto", Context.MODE_PRIVATE)
        for (s in places) {
            val lat = p.getString("lat_$s", null)?.toDoubleOrNull() ?: continue
            val lon = p.getString("lon_$s", null)?.toDoubleOrNull() ?: continue
            val r = FloatArray(1)
            Location.distanceBetween(loc.latitude, loc.longitude, lat, lon, r)
            if (r[0] <= RADIUS_M) return s
        }
        return null
    }

    fun saveHere(c: Context, status: String): Boolean {
        val loc = lastLocation(c) ?: return false
        c.getSharedPreferences("auto", Context.MODE_PRIVATE).edit()
            .putString("lat_$status", loc.latitude.toString())
            .putString("lon_$status", loc.longitude.toString()).apply()
        return true
    }

    @SuppressLint("MissingPermission")
    private fun lastLocation(c: Context): Location? = try {
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
    } catch (_: Exception) { null }

    private fun inCalendarEvent(c: Context): Boolean {
        val now = System.currentTimeMillis()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, now); ContentUris.appendId(b, now + 1)
        return c.contentResolver.query(
            b.build(), arrayOf(CalendarContract.Instances.TITLE),
            "${CalendarContract.Instances.ALL_DAY}=0", null, null
        )?.use { it.count > 0 } ?: false
    }
}
