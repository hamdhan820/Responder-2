# Responder

Android app that automatically texts people who call you, with a message matching your status (Worship, Meeting, Market (detected automatically)). Neon-themed UI.

## How it works
Status is detected automatically when a call arrives:
1. A calendar event happening now means **Meeting**.
2. Otherwise, if you are within 150 m of a place you saved (Worship, Market, Meeting place), that status is used.
3. If nothing matches, no message is sent.

## Open and run
1. Open this folder in **Android Studio** (it creates the Gradle wrapper and syncs).
2. Run on a phone with a SIM. Turn on the switch and allow Phone, Call log, SMS, Calendar and Location (choose "Allow all the time").
3. Stand at each place and tap its "Save here" button once.

## Images
- Icon: `app/src/main/res/mipmap-*/ic_launcher.png` and `drawable-nodpi/ic_launcher_fg.png`.
- Backgrounds: `drawable-nodpi/bg_*.jpg` (use the Change Background button in the app).

## Notes
- Android only (iOS does not allow automatic SMS).
- The same caller is not texted again within 5 minutes.
- Carrier SMS charges may apply.

## Automatic APK build
Every push to `main` builds the app on GitHub. Open the **Actions** tab, click the latest run, and download **Responder-APK** at the bottom. Unzip it and install `app-debug.apk` on your phone (allow "Install unknown apps").
